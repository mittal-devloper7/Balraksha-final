import { pipeline, env } from "./libs/transformers.bundle.js";

env.allowLocalModels = false;
env.backends.onnx.wasm.wasmPaths = {
  mjs: chrome.runtime.getURL("libs/ort-wasm-simd-threaded.mjs"),
  wasm: chrome.runtime.getURL("libs/ort-wasm-simd-threaded.wasm"),
};
env.backends.onnx.wasm.numThreads = 1;
env.backends.onnx.wasm.proxy = false;

// One multilingual NLI model is used for every message. There are no
// keyword lists or special-case words: risk comes only from model scores.
const MODEL_ID = "onnx-community/multilingual-MiniLMv2-L6-mnli-xnli-ONNX";
const RISK_LABELS = [
  "harassment, bullying, or insulting another person",
  "a threat or violent language toward another person",
  "grooming or manipulation of a child",
  "asking a child to keep a secret or hide something from their parents or trusted adults",
  "sexual or intimate content involving a child",
  "asking a child for private information, photos, or videos",
];

let classifierPromise = null;

function getClassifier() {
  if (!classifierPromise) {
    classifierPromise = pipeline("zero-shot-classification", MODEL_ID, { dtype: "q8" });
  }
  return classifierPromise;
}

getClassifier().then(
  () => chrome.runtime.sendMessage({ type: "BALRAKSHA_MODEL_READY" }),
  (err) => chrome.runtime.sendMessage({ type: "BALRAKSHA_MODEL_ERROR", error: String(err) }),
);

function normalizeText(text) {
  return String(text || "").replace(/\s+/g, " ").trim();
}

function languageHint(text) {
  if (/^[\x00-\x7F]*$/.test(text)) return "Latin/English-script";
  if (/[\u0900-\u097F]/.test(text)) return "Hindi/Devanagari";
  if (/[\u0980-\u09FF]/.test(text)) return "Bengali";
  if (/[\u0B80-\u0BFF]/.test(text)) return "Tamil";
  if (/[\u0C00-\u0C7F]/.test(text)) return "Telugu";
  if (/[\u0A80-\u0AFF]/.test(text)) return "Gujarati";
  if (/[\u0C80-\u0CFF]/.test(text)) return "Kannada";
  if (/[\u0D00-\u0D7F]/.test(text)) return "Malayalam";
  if (/[\u0A00-\u0A7F]/.test(text)) return "Punjabi";
  return "multilingual";
}

function calculateRisk(result) {
  const scored = result.labels.map((label, i) => ({
    label,
    score: Number(result.scores[i]) || 0,
  }));

  const sorted = [...scored].sort((a, b) => b.score - a.score);
  const top = sorted[0] || { label: null, score: 0 };

  // With multi_label=true each risk category is scored independently.
  // This is important: a safe category is not allowed to suppress a genuine
  // threat/bullying signal simply because the labels compete for one softmax.
  // Keep the model probability as the score; do not inject word/phrase rules.
  const score = Math.round(Math.max(0, Math.min(1, top.score)) * 100);
  const topLabel = top.score > 0 ? top.label : "normal, safe conversation";

  return {
    score,
    topLabel,
    normalScore: Math.max(0, 100 - score),
    runnerUp: score,
    lexical: false,
    breakdown: scored.sort((a, b) => b.score - a.score),
  };
}

async function classify(text) {
  const normalized = normalizeText(text);
  if (!normalized) throw new Error("Empty message");

  const classifier = await getClassifier();
  const result = await classifier(normalized, RISK_LABELS, {
    multi_label: true,
    hypothesis_template: "This message contains {}.",
  });

  return {
    ...calculateRisk(result),
    language: languageHint(normalized),
    multilingualModel: true,
  };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "BALRAKSHA_PING") {
    sendResponse({ ok: true });
    return false;
  }

  if (msg.type === "BALRAKSHA_OFFSCREEN_CLASSIFY") {
    classify(msg.text)
      .then((result) => sendResponse({ ok: true, result }))
      .catch((err) => sendResponse({ ok: false, error: String(err) }));
    return true;
  }

  return false;
});
