const toggle = document.getElementById("toggle-enabled");
const incidentCountEl = document.getElementById("incident-count");
const lastScoreEl = document.getElementById("last-score");
const modelStatusEl = document.getElementById("model-status");
const highInput = document.getElementById("threshold-high");
const mediumInput = document.getElementById("threshold-medium");
const thresholdStatusEl = document.getElementById("threshold-status");
const resetAlertsButton = document.getElementById("reset-alerts");
const STATUS_LABEL = { loading: "loading…", ready: "ready", error: "error" };
const DEFAULT_THRESHOLD_HIGH = 80;
const DEFAULT_THRESHOLD_MEDIUM = 45;

function clamp(n, lo, hi) {
  return Math.min(hi, Math.max(lo, n));
}

function loadThresholds() {
  chrome.storage.local.get(["balraksha_threshold_high", "balraksha_threshold_medium"], (res) => {
    highInput.value = Number.isFinite(res.balraksha_threshold_high) ? res.balraksha_threshold_high : DEFAULT_THRESHOLD_HIGH;
    mediumInput.value = Number.isFinite(res.balraksha_threshold_medium) ? res.balraksha_threshold_medium : DEFAULT_THRESHOLD_MEDIUM;
  });
}

function saveThresholds() {
  let high = clamp(Math.round(Number(highInput.value)), 0, 100);
  let medium = clamp(Math.round(Number(mediumInput.value)), 0, 100);
  if (!Number.isFinite(high)) high = DEFAULT_THRESHOLD_HIGH;
  if (!Number.isFinite(medium)) medium = DEFAULT_THRESHOLD_MEDIUM;
  if (medium > high) medium = high; // medium threshold can never exceed high
  highInput.value = high;
  mediumInput.value = medium;
  chrome.storage.local.set({ balraksha_threshold_high: high, balraksha_threshold_medium: medium }, () => {
    thresholdStatusEl.hidden = false;
    thresholdStatusEl.textContent = `Saved: High ≥ ${high}%, Medium ≥ ${medium}%.`;
    clearTimeout(thresholdStatusEl.__hideTimer);
    thresholdStatusEl.__hideTimer = setTimeout(() => (thresholdStatusEl.hidden = true), 1800);
  });
}

highInput.addEventListener("change", saveThresholds);
mediumInput.addEventListener("change", saveThresholds);

function refresh() {
  chrome.storage.local.get(["balraksha_enabled", "balraksha_incident_count", "balraksha_last_score", "balraksha_model_status"], (res) => {
    toggle.checked = res.balraksha_enabled !== false;
    incidentCountEl.textContent = res.balraksha_incident_count || 0;
    const lastScore = Number.isFinite(Number(res.balraksha_last_score)) ? Number(res.balraksha_last_score) : 0;
    lastScoreEl.textContent = `${lastScore}%`;
    const status = res.balraksha_model_status || "loading";
    modelStatusEl.textContent = STATUS_LABEL[status] || status;
    modelStatusEl.className = `pop-badge ${status}`;
  });
}

refresh();
loadThresholds();
chrome.storage.onChanged.addListener((changes, area) => { if (area === "local") refresh(); });

toggle.addEventListener("change", () => {
  const enabled = toggle.checked;
  chrome.storage.local.set({ balraksha_enabled: enabled });
  chrome.tabs.query({ url: ["*://web.whatsapp.com/*", "*://www.instagram.com/*", "*://discord.com/*"] }, (tabs) => {
    tabs.forEach((tab) => chrome.tabs.sendMessage(tab.id, { type: "BALRAKSHA_TOGGLE", enabled }, () => void chrome.runtime.lastError));
  });
});

resetAlertsButton.addEventListener("click", () => {
  chrome.storage.local.set({ balraksha_incident_count: 0, balraksha_last_score: 0 });
  thresholdStatusEl.hidden = false;
  thresholdStatusEl.textContent = "Alert count reset.";
  clearTimeout(thresholdStatusEl.__hideTimer);
  thresholdStatusEl.__hideTimer = setTimeout(() => (thresholdStatusEl.hidden = true), 1800);
});
