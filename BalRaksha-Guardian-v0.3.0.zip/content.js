/**
 * BalRaksha Content Script
 * ------------------------------------------------------
 * Watches the chat DOM, extracts new message text, and sends it to
 * the background worker for classification by the real on-device
 * model (hosted in the offscreen document — see offscreen.js).
 * This file does NOT decide risk itself; it only displays whatever
 * the model returns.
 *
 * NOTE ON SELECTORS: WhatsApp Web / Instagram / Discord change their
 * DOM structure often. The selectors below are a starting point —
 * inspect-element on the live page during testing and adjust
 * messageTextSelector for your target platform if messages aren't
 * being picked up.
 */

const HOST = window.location.hostname;

const PLATFORM_CONFIG = {
  "web.whatsapp.com": {
    chatContainerSelectors: [
      "#main",
      "div[data-testid='conversation-panel-messages']",
    ],
    messageTextSelector: "span.selectable-text, .copyable-text",
  },
  "www.instagram.com": {
    chatContainerSelectors: ["div[role='grid']", "section main"],
    messageTextSelector: "div[dir='auto']",
  },
  "discord.com": {
    chatContainerSelectors: [
      "main[class*='chatContent']",
      "ol[class*='scrollerInner']",
    ],
    messageTextSelector: "div[class*='messageContent']",
  },
};

const config = PLATFORM_CONFIG[HOST];
if (!config) {
  console.warn("[BalRaksha] Unsupported host:", HOST);
}

let seenMessageNodes = new WeakMap();
let trackedContainer = null;
let initialScanComplete = false;
let bannerEl = null;
let extensionEnabled = true;
let latestRequestId = 0;
let dismissedUntil = 0;

function classifyText(text, requestId) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      { type: "BALRAKSHA_CLASSIFY", text, requestId },
      (response) => {
        if (chrome.runtime.lastError) {
          resolve({ ok: false, error: chrome.runtime.lastError.message });
          return;
        }
        resolve(response || { ok: false, error: "No response" });
      },
    );
  });
}

function handleNewText(text) {
  const requestId = ++latestRequestId;
  showLoadingBanner();
  classifyText(text, requestId).then((response) => {
    // A newer message has appeared while this model call was running.
    if (requestId !== latestRequestId) return;

    if (!response.ok) {
      showErrorBanner(response.error);
      return;
    }

    const { score, topLabel, breakdown, riskLevel } = response;
    if (riskLevel === "HIGH" || riskLevel === "MEDIUM") {
      showResultBanner({ score, topLabel, breakdown, riskLevel });
    } else {
      hideBanner();
    }
  });
}
function ensureBanner() {
  if (!bannerEl) {
    bannerEl = document.createElement("div");
    bannerEl.id = "balraksha-banner";
    document.body.appendChild(bannerEl);
  }
  return bannerEl;
}

function showLoadingBanner() {
  if (Date.now() < dismissedUntil) return;
  const el = ensureBanner();
  el.className = "br-banner br-loading";
  el.innerHTML = `
    <div class="br-header">
      <span class="br-icon">🛡️</span>
      <span class="br-title">BalRaksha Guard</span>
    </div>
    <div class="br-body">
      <div class="br-risk-line">Analyzing locally…</div>
    </div>
  `;
}

function showErrorBanner(error) {
  const el = ensureBanner();
  el.className = "br-banner br-loading";
  el.innerHTML = `
    <div class="br-header">
      <span class="br-icon">🛡️</span>
      <span class="br-title">BalRaksha Guard</span>
      <button class="br-close" aria-label="Dismiss">×</button>
    </div>
    <div class="br-body">
      <div class="br-risk-line">Model unavailable: ${escapeHtml(error || "unknown error")}</div>
    </div>
  `;
  el.querySelector(".br-close").onclick = () => hideBanner(true);
}

function showResultBanner({ score, topLabel, breakdown, riskLevel }) {
  if (Date.now() < dismissedUntil) return;
  const el = ensureBanner();
  const riskClass = riskLevel === "HIGH" ? "br-high" : "br-medium";
  el.className = `br-banner ${riskClass}`;

  const breakdownRows = breakdown
    .map(
      (b) => `
      <div class="br-bar-row">
        <span class="br-bar-label">${escapeHtml(b.label)}</span>
        <div class="br-bar-track"><div class="br-bar-fill" style="width:${Math.round(b.score * 100)}%"></div></div>
        <span class="br-bar-pct">${Math.round(b.score * 100)}%</span>
      </div>`,
    )
    .join("");

  el.innerHTML = `
    <div class="br-header">
      <span class="br-icon">🛡️</span>
      <span class="br-title">BalRaksha Guard</span>
      <button class="br-close" aria-label="Dismiss">×</button>
    </div>
    <div class="br-body">
      <div class="br-risk-line">Risk: <strong>${riskLevel}</strong> (${score}%)</div>
      <div class="br-actions">
        <button class="br-btn br-see-why">See Why</button>
        <button class="br-btn br-get-help">Get Help</button>
      </div>
      <div class="br-details" hidden>
        <div class="br-signals-title">Model classification (on-device):</div>
        ${breakdownRows}
        <div class="br-privacy-note">Analysis performed locally by an on-device model. Your messages were not uploaded.</div>
        <button class="br-btn br-report">Report Safely</button>
      </div>
    </div>
  `;

  el.querySelector(".br-close").onclick = () => hideBanner(true);
  el.querySelector(".br-see-why").onclick = () => {
    const details = el.querySelector(".br-details");
    details.hidden = !details.hidden;
  };
  el.querySelector(".br-get-help").onclick = () =>
    openHelp({ score, topLabel, riskLevel });
  el.querySelector(".br-report")?.addEventListener("click", () =>
    openReport({ score, topLabel, riskLevel }),
  );
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

function hideBanner(snooze = false) {
  if (snooze) dismissedUntil = Date.now() + 30 * 1000;
  if (bannerEl) bannerEl.remove();
  bannerEl = null;
}

function openHelp({ score, topLabel, riskLevel }) {
  const params = new URLSearchParams({
    risk: riskLevel,
    score: String(score),
    label: topLabel || "",
  });
  chrome.runtime.sendMessage({
    type: "BALRAKSHA_OPEN_HELP",
    url: `https://www.spniwcd.wcd.gov.in/child-helpline?risk=${encodeURIComponent(riskLevel)}&score=${encodeURIComponent(String(score))}&label=${encodeURIComponent(topLabel || "")}`,
  });
}

function openReport({ score, topLabel, riskLevel }) {
  const reportData = {
    riskScore: score,
    category: getCategory(topLabel),
    description: `Potentially unsafe interaction detected by BalRaksha local analysis. Detected category: ${topLabel || "unknown"}.`,
    anonymous: true,
    signals: [
      {
        signal: topLabel || "UNSAFE_INTERACTION",
        description: topLabel || "Potentially unsafe interaction detected.",
        weight: score,
      },
    ],
  };

  chrome.runtime.sendMessage(
    {
      type: "BALRAKSHA_SUBMIT_REPORT",
      data: reportData,
    },
    (response) => {
      if (chrome.runtime.lastError) {
        showErrorBanner(chrome.runtime.lastError.message);
        return;
      }

      if (!response?.ok) {
        showErrorBanner(response?.error || "Could not submit report.");
        return;
      }

      showReportSuccess(response.result);
    },
  );
}

function findChatContainer() {
  for (const selector of config.chatContainerSelectors) {
    const el = document.querySelector(selector);
    if (el) return el;
  }
  return null;
}

function extractLatestMessages(container) {
  const nodes = container.querySelectorAll(config.messageTextSelector);
  const messages = [];
  nodes.forEach((node) => {
    const text = (node.textContent || "").replace(/\s+/g, " ").trim();
    if (text) messages.push({ node, text });
  });
  return messages;
}

// A short rolling window of recent message text is kept per active chat so the
// on-device model sees a bit of surrounding conversation instead of judging a
// single line in isolation. This does not add any keyword rules — it only
// gives the same model more context to reason over. Entries are also bounded
// by age: without that, a message from several minutes ago (an unrelated,
// already-resolved exchange) could still bleed into a brand-new message's
// classification and skew its score.
const CONTEXT_WINDOW = 6;
const CONTEXT_MAX_AGE_MS = 2 * 60 * 1000;
let recentContext = [];

function pushContext(text) {
  const now = Date.now();
  recentContext.push({ text, ts: now });
  recentContext = recentContext
    .filter((m) => now - m.ts <= CONTEXT_MAX_AGE_MS)
    .slice(-CONTEXT_WINDOW);
  return recentContext.map((m) => m.text).join("\n");
}

function seedContainer(container) {
  seenMessageNodes = new WeakMap();
  const messages = extractLatestMessages(container);
  messages.forEach(({ node, text }) => seenMessageNodes.set(node, text));
  trackedContainer = container;
  initialScanComplete = true;
  const now = Date.now();
  recentContext = messages.slice(-CONTEXT_WINDOW).map((m) => ({ text: m.text, ts: now }));
}

function scanOnce() {
  if (!extensionEnabled) return;
  const container = findChatContainer();
  if (!container) return;

  // WhatsApp/Instagram/Discord can replace the entire chat subtree when the
  // user changes conversations. Do not classify the old history as new.
  if (!initialScanComplete || trackedContainer !== container) {
    seedContainer(container);
    return;
  }

  const messages = extractLatestMessages(container);
  const changed = [];

  for (const { node, text } of messages) {
    const previous = seenMessageNodes.get(node);
    if (previous !== text) {
      seenMessageNodes.set(node, text);
      changed.push(text);
    }
  }

  // Every new message is classified, not just the last one seen in this
  // scan — a burst of several quick messages (e.g. an isolation attempt
  // right after a request) must not let earlier ones go unscored.
  changed.forEach((text) => handleNewText(pushContext(text)));
}

function init() {
  if (!config) return;

  chrome.storage.local.get(["balraksha_enabled"], (res) => {
    extensionEnabled = res.balraksha_enabled !== false;
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "BALRAKSHA_TOGGLE") {
      extensionEnabled = msg.enabled;
      if (!extensionEnabled) hideBanner();
    }
  });

  const observer = new MutationObserver(() => {
    clearTimeout(window.__balrakshaDebounce);
    window.__balrakshaDebounce = setTimeout(scanOnce, 250);
  });

  observer.observe(document.body, { childList: true, subtree: true, characterData: true });

  // Wait for the chat UI to exist, then seed its current history.
  const retry = () => {
    if (!initialScanComplete) {
      scanOnce();
      if (!initialScanComplete) setTimeout(retry, 1000);
    }
  };
  setTimeout(retry, 500);
}
function getCategory(label) {
  if (!label) return "OTHER";

  const value = label.toLowerCase();

  if (value.includes("groom") || value.includes("manipulat")) {
    return "GROOMING";
  }

  if (
    value.includes("photo") ||
    value.includes("video") ||
    value.includes("personal information")
  ) {
    return "PERSONAL_INFORMATION_REQUEST";
  }

  if (value.includes("harassment") || value.includes("bullying")) {
    return "BULLYING";
  }

  if (value.includes("threat")) {
    return "THREAT";
  }

  return "OTHER";
}
function showReportSuccess(result) {
  const el = ensureBanner();

  el.className = "br-banner br-high";

  el.innerHTML = `
    <div class="br-header">
      <span class="br-icon">🛡️</span>
      <span class="br-title">BalRaksha</span>
    </div>

    <div class="br-body">
      <div class="br-risk-line">
        Report submitted safely.
      </div>

      <div class="br-body">
        Reference ID:
        <strong>${escapeHtml(String(result.reportId || "N/A"))}</strong>
      </div>

      <div class="br-privacy-note">
        Your report has been sent to the BalRaksha safety system.
      </div>
    </div>
  `;
}
init();
