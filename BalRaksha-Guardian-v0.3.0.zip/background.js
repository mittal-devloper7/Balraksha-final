const OFFSCREEN_URL = "offscreen.html";
const BACKEND_URL = "http://localhost:5000";
const DEFAULT_THRESHOLD_HIGH = 80;
const DEFAULT_THRESHOLD_MEDIUM = 45;
const latestRequestByTab = new Map();

async function getThresholds() {
  const res = await chrome.storage.local.get(["balraksha_threshold_high", "balraksha_threshold_medium"]);
  const high = Number.isFinite(res.balraksha_threshold_high) ? res.balraksha_threshold_high : DEFAULT_THRESHOLD_HIGH;
  const medium = Number.isFinite(res.balraksha_threshold_medium) ? res.balraksha_threshold_medium : DEFAULT_THRESHOLD_MEDIUM;
  return { high, medium };
}

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function pingOffscreen() {
  try {
    const res = await chrome.runtime.sendMessage({ type: "BALRAKSHA_PING" });
    return !!res?.ok;
  } catch { return false; }
}

async function ensureOffscreenReady() {
  const has = await chrome.offscreen.hasDocument?.();
  if (!has) {
    await chrome.offscreen.createDocument({
      url: OFFSCREEN_URL,
      reasons: ["DOM_SCRAPING"],
      justification: "Runs on-device ML for private chat-safety analysis.",
    });
  }
  for (const wait of [50, 150, 300, 600, 1000]) {
    if (await pingOffscreen()) return true;
    await delay(wait);
  }
  return false;
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({
    balraksha_enabled: true,
    balraksha_incident_count: 0,
    balraksha_last_score: 0,
    balraksha_model_status: "loading",
    balraksha_threshold_high: DEFAULT_THRESHOLD_HIGH,
    balraksha_threshold_medium: DEFAULT_THRESHOLD_MEDIUM,
  });
  ensureOffscreenReady();
});
chrome.runtime.onStartup.addListener(() => ensureOffscreenReady());

async function submitThreatReport(data) {
  try {
    const response = await fetch(`${BACKEND_URL}/api/threat/analyze`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    let result = {};
    try { result = await response.json(); } catch { result = {}; }
    if (!response.ok) return { ok: false, error: result.message || `Report service returned HTTP ${response.status}.` };
    return { ok: true, result };
  } catch (error) {
    return { ok: false, error: `Report service unavailable at ${BACKEND_URL}. ${error.message}` };
  }
}

async function offscreenRequest(type, payload) {
  const ready = await ensureOffscreenReady();
  if (!ready) return { ok: false, error: "On-device analyzer did not become ready." };
  return chrome.runtime.sendMessage({ type, ...payload });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "BALRAKSHA_SUBMIT_REPORT") {
    submitThreatReport(msg.data).then(sendResponse);
    return true;
  }

  if (msg.type === "BALRAKSHA_MODEL_READY") {
    chrome.storage.local.set({ balraksha_model_status: "ready" });
    return false;
  }
  if (msg.type === "BALRAKSHA_MODEL_ERROR") {
    chrome.storage.local.set({ balraksha_model_status: "error" });
    console.error("[BalRaksha] Model failed to load:", msg.error);
    return false;
  }

  if (msg.type === "BALRAKSHA_CLASSIFY") {
    (async () => {
      try {
        const tabId = sender?.tab?.id;
        if (Number.isInteger(tabId) && Number.isInteger(msg.requestId)) {
          latestRequestByTab.set(tabId, msg.requestId);
        }
        const response = await offscreenRequest("BALRAKSHA_OFFSCREEN_CLASSIFY", { text: msg.text });
        if (!response?.ok) {
          sendResponse({ ok: false, error: response?.error || "Unknown classification error" });
          return;
        }
        const { score } = response.result;
        const { high, medium } = await getThresholds();
        const riskLevel = score >= high ? "HIGH" : score >= medium ? "MEDIUM" : "LOW";
        const isLatest = !Number.isInteger(tabId) || !Number.isInteger(msg.requestId) || latestRequestByTab.get(tabId) === msg.requestId;

        // A HIGH-risk result must never be dropped just because a newer
        // message arrived before this one's classification finished — that
        // is exactly the situation (a fast burst of messages) where missing
        // an alert matters most. Recency only decides what's shown as the
        // "live" score, never whether a genuine alert gets counted.
        if (riskLevel === "HIGH") {
          const res = await chrome.storage.local.get(["balraksha_incident_count"]);
          await chrome.storage.local.set({ balraksha_incident_count: (res.balraksha_incident_count || 0) + 1 });
        }
        if (isLatest) {
          await chrome.storage.local.set({ balraksha_last_score: score });
        }
        sendResponse({ ok: true, ...response.result, riskLevel });
      } catch (err) {
        sendResponse({ ok: false, error: String(err) });
      }
    })();
    return true;
  }

  if (msg.type === "BALRAKSHA_OPEN_HELP") {
    chrome.tabs.create({ url: msg.url });
    return false;
  }

  return false;
});
