# BalRaksha Guardian

BalRaksha is a Chrome extension that performs chat-safety classification locally in the browser.

## Current behavior
- Analyzes newly observed chat messages rather than the existing conversation history at startup.
- The newest message is given priority; an older classification cannot overwrite a newer result.
- Uses an on-device zero-shot transformer classifier.
- Supports English, Indian-script text, and common Hindi written in English (Hinglish).
- Uses a conservative confidence/margin gate to reduce false positives on ordinary conversation.
- Sexual/intimate requests, grooming/manipulation, personal-information requests and threats receive stronger weighting.
- No screenshot capture or screenshot upload functionality.
- Alerts can be dismissed for 30 seconds and the counter can be reset from the popup.

## Using the extension
- Load the `balraksha-extension` folder from `chrome://extensions` using **Load unpacked**.
- Open a supported chat site, then use the extension popup to turn protection on or off and tune alert sensitivity.
- The optional **Report Safely** action sends only an anonymized risk summary to a locally running BalRaksha report service (`http://localhost:5000`); it does not send chat text.
